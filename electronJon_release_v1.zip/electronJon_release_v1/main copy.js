const { app, BrowserWindow, globalShortcut, ipcMain, screen } = require('electron');
const { GlobalKeyboardListener } = require('node-global-key-listener');
const { setupAvatarBridge } = require('./bridge');

let mainWindow;      // Your full app window (port 3000)
let avatarWindow;    // The always-on-top avatar window
let isRecording = false;
let keyboardListener = null;
let visibilityCheckInterval;

// Backend configuration
const BACKEND_URL = 'http://localhost:8001';
const FULL_APP_URL = 'http://localhost:3000';
let currentSessionId = null;
let currentVoice = 'jonnydepp';

function createWindows() {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width: screenWidth, height: screenHeight } = primaryDisplay.workAreaSize;
  
  // ============ MAIN APP WINDOW (Your full application) ============
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    x: 50,
    y: 50,
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false
    }
  });
  
  mainWindow.loadURL(FULL_APP_URL);
  mainWindow.once('ready-to-show', () => {
    console.log('📱 Main app window ready');
    // Don't show by default - user can open when needed
  });
  
  // ============ AVATAR WINDOW (Always-on-top) ============
  const avatarWidth = 625;
  const avatarHeight = 450;
  const xPos = screenWidth - avatarWidth;
  
  avatarWindow = new BrowserWindow({
    width: avatarWidth,
    height: avatarHeight,
    x: xPos,
    y: 0,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    focusable: true,
    resizable: false,
    skipTaskbar: true,
    backgroundColor: '#00FFFFFF',
    type: 'toolbar',
    show: false,
    minWidth: avatarWidth,
    maxWidth: avatarWidth,
    minHeight: avatarHeight,
    maxHeight: avatarHeight,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false,
      partition: 'persist:imtalker'
    }
  });

  console.log(`📐 Avatar window positioned at (${xPos}, 0)`);

  const forceAlwaysOnTop = () => {
    if (avatarWindow.isDestroyed()) return;
    
    const levels = ['screen-saver', 'modal-panel', 'main-menu', 'status', 'pop-up-menu', 'critical'];
    
    for (const level of levels) {
      try {
        avatarWindow.setAlwaysOnTop(true, level);
        break;
      } catch (err) {
        continue;
      }
    }
    
    if (!avatarWindow.isVisible()) {
      avatarWindow.showInactive();
    }
    
    if (avatarWindow.isMinimized()) {
      avatarWindow.restore();
    }
  };

  avatarWindow.once('ready-to-show', () => {
    avatarWindow.show();
    forceAlwaysOnTop();
    console.log('👁️ Avatar window shown and pinned on top');
  });

  visibilityCheckInterval = setInterval(forceAlwaysOnTop, 2000);

  avatarWindow.on('blur', () => {
    console.log('🔍 Avatar window blurred - maintaining visibility');
    avatarWindow.setOpacity(0.95);
    avatarWindow.setAlwaysOnTop(true, 'floating');
  });

  avatarWindow.on('focus', () => {
    console.log('🔍 Avatar window focused');
    avatarWindow.setOpacity(1.0);
    avatarWindow.setAlwaysOnTop(true, 'normal');
  });

  avatarWindow.on('minimize', (event) => {
    event.preventDefault();
    console.log('🚫 Minimize blocked');
    forceAlwaysOnTop();
  });

  // Load the minimal avatar HTML
  avatarWindow.webContents.session.clearCache().then(() => {
    const timestamp = Date.now();
    const avatarHtmlPath = `file://${__dirname}/avatar.html?t=${timestamp}`;
    
    console.log('🚀 Loading avatar window:', avatarHtmlPath);
    avatarWindow.loadURL(avatarHtmlPath);
  }).catch(err => {
    console.error('Cache clear failed:', err);
    avatarWindow.loadURL(`file://${__dirname}/avatar.html`);
  });

  avatarWindow.webContents.on('did-finish-load', () => {
    console.log("✅ Avatar window loaded");
    
    // Inject clean UI styles
    avatarWindow.webContents.executeJavaScript(`
      document.body.style.margin = '0';
      document.body.style.padding = '0';
      document.body.style.overflow = 'hidden';
      document.body.style.webkitAppRegion = 'drag';
      document.documentElement.style.overflow = 'hidden';
      document.documentElement.style.width = '100%';
      document.documentElement.style.height = '100%';
      
      // Status indicators
      const backendStatus = document.createElement('div');
      backendStatus.id = 'backend-status';
      backendStatus.style.position = 'fixed';
      backendStatus.style.bottom = '2px';
      backendStatus.style.right = '2px';
      backendStatus.style.width = '8px';
      backendStatus.style.height = '8px';
      backendStatus.style.borderRadius = '4px';
      backendStatus.style.zIndex = '9999';
      backendStatus.style.transition = 'background 0.3s';
      backendStatus.style.background = 'rgba(255, 165, 0, 0.5)';
      backendStatus.title = 'Checking backend...';
      document.body.appendChild(backendStatus);
      
      const sessionInfo = document.createElement('div');
      sessionInfo.id = 'session-info';
      sessionInfo.style.position = 'fixed';
      sessionInfo.style.bottom = '2px';
      sessionInfo.style.left = '2px';
      sessionInfo.style.color = 'rgba(255, 255, 255, 0.5)';
      sessionInfo.style.fontSize = '10px';
      sessionInfo.style.fontFamily = 'monospace';
      sessionInfo.style.zIndex = '9999';
      sessionInfo.style.padding = '2px 6px';
      sessionInfo.style.background = 'rgba(0, 0, 0, 0.3)';
      sessionInfo.style.borderRadius = '3px';
      document.body.appendChild(sessionInfo);
      
      console.log("✅ Avatar UI ready");
    `);
    
    forceAlwaysOnTop();
    checkBackendHealth();
  });

  avatarWindow.on('closed', () => {
    if (visibilityCheckInterval) {
      clearInterval(visibilityCheckInterval);
    }
  });

  // Setup the bridge between windows
  setupAvatarBridge(avatarWindow, mainWindow);
  
  // Setup IPC handlers for bridge communication
  setupIpcHandlers();
  
  // Setup keyboard listener
  setupGlobalKeyboardListener();
}

// ============ IPC HANDLERS FOR BRIDGE ============

function setupIpcHandlers() {
  // From avatar: voice command received
  ipcMain.on('avatar-voice-command', async (event, audioData) => {
    console.log('🎤 Avatar voice command received, forwarding to backend');
    
    // Send to Python backend
    const blob = new Blob([audioData], { type: 'audio/webm' });
    const result = await sendAudioToBackend(blob);
    
    // Forward result to main app if it exists
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('process-voice-result', result);
    }
    
    // Update avatar with processing status
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.webContents.send('avatar-update', {
        type: 'status',
        text: 'Processing...',
        sessionId: result?.session_id
      });
    }
  });
  
  // From avatar: text command
  ipcMain.on('avatar-text-command', async (event, text) => {
    console.log(`📝 Avatar text command: "${text.substring(0, 50)}..."`);
    
    const result = await sendTextToBackend(text);
    
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('process-text-result', result);
    }
    
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.webContents.send('avatar-update', {
        type: 'status',
        text: 'Generating response...',
        sessionId: result?.session_id
      });
    }
  });
  
  // From main app: update avatar display
  ipcMain.on('update-avatar', (event, data) => {
    console.log('📱 Main app updating avatar:', data.type);
    
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.webContents.send('avatar-update', data);
    }
  });
  
  // From main app: show/hide avatar
  ipcMain.on('show-avatar', () => {
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.show();
      avatarWindow.focus();
    }
  });
  
  ipcMain.on('hide-avatar', () => {
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.hide();
    }
  });
  
  // From main app: show main window
  ipcMain.on('show-main-app', () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

// ============ BACKEND INTEGRATION ============

async function checkBackendHealth() {
  try {
    const response = await fetch(`${BACKEND_URL}/voices`);
    if (response.ok) {
      console.log(`✅ Backend healthy`);
      
      if (avatarWindow && !avatarWindow.isDestroyed()) {
        avatarWindow.webContents.executeJavaScript(`
          const indicator = document.getElementById('backend-status');
          if (indicator) {
            indicator.style.background = 'rgba(0, 255, 0, 0.5)';
            indicator.title = 'Backend connected';
          }
        `);
      }
      return true;
    }
  } catch (err) {
    console.warn('⚠️ Backend not responding');
    
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      avatarWindow.webContents.executeJavaScript(`
        const indicator = document.getElementById('backend-status');
        if (indicator) {
          indicator.style.background = 'rgba(255, 0, 0, 0.5)';
          indicator.title = 'Backend disconnected';
        }
      `);
    }
  }
  return false;
}

async function sendTextToBackend(text) {
  try {
    const formData = new FormData();
    formData.append('text', text);
    formData.append('voice', currentVoice);
    
    const response = await fetch(`${BACKEND_URL}/chat`, {
      method: 'POST',
      body: formData
    });
    
    if (response.ok) {
      const data = await response.json();
      currentSessionId = data.session_id;
      
      if (avatarWindow && !avatarWindow.isDestroyed()) {
        avatarWindow.webContents.executeJavaScript(`
          const info = document.getElementById('session-info');
          if (info) {
            info.textContent = 'Session: ${data.session_id} | Chunks: ${data.total_chunks}';
          }
        `);
      }
      
      if (data.session_id) {
        pollChunkStatus(data.session_id, data.total_chunks);
      }
      
      return data;
    }
  } catch (err) {
    console.error('Backend error:', err);
  }
  return null;
}

async function sendAudioToBackend(audioBlob) {
  try {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    formData.append('voice', currentVoice);
    
    const response = await fetch(`${BACKEND_URL}/chat`, {
      method: 'POST',
      body: formData
    });
    
    if (response.ok) {
      const data = await response.json();
      currentSessionId = data.session_id;
      
      if (avatarWindow && !avatarWindow.isDestroyed()) {
        avatarWindow.webContents.executeJavaScript(`
          const info = document.getElementById('session-info');
          if (info) {
            info.textContent = 'Session: ${data.session_id} | 🎤: "${data.transcript?.substring(0, 30)}..."';
          }
        `);
      }
      
      if (data.session_id) {
        pollChunkStatus(data.session_id, data.total_chunks);
      }
      
      return data;
    }
  } catch (err) {
    console.error('Backend error:', err);
  }
  return null;
}

async function pollChunkStatus(sessionId, totalChunks) {
  console.log(`🔄 Polling chunks for ${sessionId}`);
  
  let lastReadyCount = -1;
  
  const poll = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/chunk_status/${sessionId}`);
      if (response.ok) {
        const status = await response.json();
        const readyCount = status.ready.filter(r => r).length;
        
        if (readyCount !== lastReadyCount) {
          console.log(`📊 Progress: ${readyCount}/${totalChunks}`);
          lastReadyCount = readyCount;
          
          // Update avatar with ready chunks
          for (let i = 0; i < status.ready.length; i++) {
            if (status.ready[i]) {
              const chunkUrl = `${BACKEND_URL}/chunks/stream_${sessionId}_${i}.mp4`;
              
              if (avatarWindow && !avatarWindow.isDestroyed()) {
                avatarWindow.webContents.send('avatar-update', {
                  type: 'video',
                  chunkIndex: i,
                  url: chunkUrl,
                  sessionId: sessionId
                });
              }
            }
          }
        }
        
        if (readyCount < totalChunks) {
          setTimeout(poll, 500);
        } else {
          console.log(`✅ All chunks ready`);
          
          if (avatarWindow && !avatarWindow.isDestroyed()) {
            avatarWindow.webContents.send('avatar-update', {
              type: 'complete',
              sessionId: sessionId
            });
          }
        }
      }
    } catch (err) {
      console.error('Poll error:', err);
      setTimeout(poll, 1000);
    }
  };
  
  poll();
}

// ============ KEYBOARD LISTENER ============

function setupGlobalKeyboardListener() {
  let ctrlPressed = false;
  
  keyboardListener = new GlobalKeyboardListener();
  
  keyboardListener.addListener((e, down) => {
    if (e.name === "LEFT CTRL" || e.name === "RIGHT CTRL") {
      ctrlPressed = (e.state === "DOWN");
    }
    
    // Ctrl+Space: Start/stop recording
    if (e.name === "SPACE" && ctrlPressed) {
      if (e.state === "DOWN" && !isRecording) {
        console.log('🎤 START recording');
        isRecording = true;
        
        if (avatarWindow && !avatarWindow.isDestroyed()) {
          avatarWindow.focus();
          avatarWindow.webContents.send('start-recording');
        }
      } else if (e.state === "UP" && isRecording) {
        console.log('🎤 STOP recording');
        isRecording = false;
        
        if (avatarWindow && !avatarWindow.isDestroyed()) {
          avatarWindow.webContents.send('stop-recording');
        }
      }
    }
    
    // Ctrl+Shift+A: Toggle avatar visibility
    if (e.name === "A" && e.state === "DOWN" && ctrlPressed && e.shiftKey) {
      if (avatarWindow && !avatarWindow.isDestroyed()) {
        if (avatarWindow.isVisible()) {
          avatarWindow.hide();
        } else {
          avatarWindow.show();
        }
      }
    }
    
    // Ctrl+Shift+M: Show main app
    if (e.name === "M" && e.state === "DOWN" && ctrlPressed && e.shiftKey) {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.show();
        mainWindow.focus();
      }
    }
    
    // Voice switching
    if (e.name === "1" && e.state === "DOWN" && ctrlPressed) {
      currentVoice = 'jonnydepp';
      console.log('🎤 Voice: Jonny Depp');
    }
    if (e.name === "2" && e.state === "DOWN" && ctrlPressed) {
      currentVoice = 'alba';
      console.log('🎤 Voice: Alba');
    }
  });
  
  console.log('✅ Keyboard listener activated');
}

// ============ APP LIFECYCLE ============

app.whenReady().then(async () => {
  const { session } = require('electron');
  session.defaultSession.clearCache();
  
  console.log('🧹 Cache cleared');
  console.log('🎬 Electron Avatar with Bridge');
  console.log(`📍 Backend: ${BACKEND_URL}`);
  console.log(`📍 Full app: ${FULL_APP_URL}`);
  
  createWindows();
  setTimeout(checkBackendHealth, 2000);
});

app.on('will-quit', () => {
  if (keyboardListener) {
    keyboardListener.kill();
  }
  if (visibilityCheckInterval) {
    clearInterval(visibilityCheckInterval);
  }
  console.log('👋 Cleanup complete');
});