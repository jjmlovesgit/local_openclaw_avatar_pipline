const { app, BrowserWindow, globalShortcut, ipcMain, screen } = require('electron');

let avatarWindow = null;
let isRecording = false;
let visibilityCheckInterval;

// Backend configuration
const BACKEND_URL = 'http://0.0.0.0:8002';
let currentVoice = 'jonnydepp';

function createWindow() {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width: screenWidth } = primaryDisplay.workAreaSize;
  
  // ============ AVATAR WINDOW (Always-on-top) ============
  const avatarWidth = 925;
  const avatarHeight = 725;
  const xPos = screenWidth - avatarWidth;
  
  avatarWindow = new BrowserWindow({
    width: avatarWidth,
    height: avatarHeight,
    x: xPos,
    y: 0,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    focusable: true,
    resizable: false,
    skipTaskbar: true,
    backgroundColor: '#00000000',
    type: 'toolbar',
    show: false,
    minWidth: avatarWidth,
    maxWidth: avatarWidth,
    minHeight: avatarHeight,
    maxHeight: avatarHeight,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false,
      partition: 'persist:imtalker'
    }
  });

  // CRITICAL: Make the window accept mouse events
  avatarWindow.setIgnoreMouseEvents(false);

  console.log(`📐 Avatar window positioned at (${xPos}, 0) with size ${avatarWidth}x${avatarHeight}`);

  const forceAlwaysOnTop = () => {
    if (avatarWindow.isDestroyed()) return;
    
    const levels = ['screen-saver', 'modal-panel', 'main-menu', 'status', 'pop-up-menu', 'critical'];
    
    for (const level of levels) {
      try {
        avatarWindow.setAlwaysOnTop(true, level);
        break;
      } catch (err) {
        continue;
      }
    }
    
    // Ensure mouse events are still enabled
    avatarWindow.setIgnoreMouseEvents(false);
    
    if (!avatarWindow.isVisible()) {
      avatarWindow.showInactive();
    }
    
    if (avatarWindow.isMinimized()) {
      avatarWindow.restore();
    }
  };

  avatarWindow.once('ready-to-show', () => {
    avatarWindow.show();
    avatarWindow.setIgnoreMouseEvents(false);
    forceAlwaysOnTop();
    console.log('👁️ Avatar window shown and pinned on top');
  });

  visibilityCheckInterval = setInterval(() => {
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      forceAlwaysOnTop();
      avatarWindow.setIgnoreMouseEvents(false);
    }
  }, 2000);

  avatarWindow.on('blur', () => {
    console.log('🔍 Avatar window blurred - maintaining visibility');
    avatarWindow.setOpacity(0.95);
    avatarWindow.setAlwaysOnTop(true, 'floating');
    avatarWindow.setIgnoreMouseEvents(false);
  });

  avatarWindow.on('focus', () => {
    console.log('🔍 Avatar window focused');
    avatarWindow.setOpacity(1.0);
    avatarWindow.setAlwaysOnTop(true, 'normal');
    avatarWindow.setIgnoreMouseEvents(false);
  });

  avatarWindow.on('minimize', (event) => {
    event.preventDefault();
    console.log('🚫 Minimize blocked');
    forceAlwaysOnTop();
  });

  // Load the avatar HTML
  avatarWindow.webContents.session.clearCache().then(() => {
    const timestamp = Date.now();
    const avatarHtmlPath = `file://${__dirname}/avatar.html?t=${timestamp}`;
    
    console.log('🚀 Loading avatar window:', avatarHtmlPath);
    avatarWindow.loadURL(avatarHtmlPath);
  }).catch(err => {
    console.error('Cache clear failed:', err);
    avatarWindow.loadURL(`file://${__dirname}/avatar.html`);
  });

  avatarWindow.webContents.on('dom-ready', () => {
    console.log("✅ DOM ready - injecting click fixes");
    
    // Inject CSS to ensure pointer events work
    avatarWindow.webContents.insertCSS(`
      * {
        pointer-events: auto !important;
      }
      
      html, body {
        pointer-events: auto !important;
        background: transparent !important;
      }
      
      button, input, #ai-text, #connectBtn, #sendBtn, #userInput, .wakeword-status-bar {
        pointer-events: auto !important;
        -webkit-app-region: no-drag !important;
        position: relative;
        z-index: 9999;
      }
      
      button, #connectBtn, #sendBtn {
        cursor: pointer !important;
      }
      
      input, #ai-text, #userInput {
        cursor: text !important;
      }
      
      .drag-bar {
        -webkit-app-region: drag !important;
        pointer-events: auto !important;
        z-index: 99999;
      }
      
      .drag-bar * {
        pointer-events: none !important;
        -webkit-app-region: drag !important;
      }
    `);
    
    // Inject JavaScript to ensure buttons work
    avatarWindow.webContents.executeJavaScript(`
      console.log('=== INJECTED CLICK FIX ===');
      
      // Wait for DOM to be fully ready
      setTimeout(() => {
        // Get all buttons and force enable them
        const buttons = document.querySelectorAll('button');
        console.log('Found buttons:', buttons.length);
        
        buttons.forEach(btn => {
          btn.disabled = false;
          btn.style.pointerEvents = 'auto';
          btn.style.cursor = 'pointer';
          btn.style.zIndex = '9999';
          console.log('Enabled button:', btn.id || btn.textContent);
        });
        
        // Force enable input
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
          input.disabled = false;
          input.style.pointerEvents = 'auto';
          input.style.cursor = 'text';
          input.style.zIndex = '9999';
          console.log('Enabled input:', input.id);
        });
        
        // Focus the input
        const userInput = document.getElementById('userInput');
        if (userInput) {
          userInput.focus();
        }
      }, 100);
      
      // Global click handler for debugging
      document.addEventListener('click', (e) => {
        console.log('Click detected on:', e.target.tagName, e.target.id || e.target.className);
      }, true);
      
      console.log('Click fix injected successfully');
    `);
  });

  avatarWindow.webContents.on('did-finish-load', () => {
    console.log("✅ Avatar window loaded");
    avatarWindow.setIgnoreMouseEvents(false);
    forceAlwaysOnTop();
    
    // Register global shortcuts AFTER window is loaded
    registerGlobalShortcuts();
  });

  avatarWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
    console.error('❌ Load failed:', errorCode, errorDescription);
    setTimeout(() => {
      avatarWindow.loadURL(`file://${__dirname}/avatar.html?retry=${Date.now()}`);
    }, 2000);
  });

  avatarWindow.on('closed', () => {
    if (visibilityCheckInterval) {
      clearInterval(visibilityCheckInterval);
    }
  });
}

// ============ REGISTER GLOBAL SHORTCUTS - ELECTRON NATIVE ============
function registerGlobalShortcuts() {
  // Unregister any existing shortcuts first
  globalShortcut.unregisterAll();
  
  console.log('========================================');
  console.log('🌍 REGISTERING GLOBAL SHORTCUTS');
  console.log('========================================');
  
  // ============ PUSH-TO-TALK: Ctrl+Shift+Space ============
  // Register DOWN event
  const downRegistered = globalShortcut.register('Ctrl+Shift+Space', () => {
    if (!isRecording) {
      isRecording = true;
      console.log('🎤 Ctrl+Shift+Space - START recording (GLOBAL)');
      
      if (avatarWindow && !avatarWindow.isDestroyed()) {
        avatarWindow.webContents.send('voice-record-start');
      }
    }
  });
  
  console.log(`   Ctrl+Shift+Space DOWN: ${downRegistered ? '✅ REGISTERED' : '❌ FAILED'}`);
  
  if (!downRegistered) {
    console.log('   Trying Alt+Space as fallback...');
    const altDownRegistered = globalShortcut.register('Alt+Space', () => {
      if (!isRecording) {
        isRecording = true;
        console.log('🎤 Alt+Space - START recording (GLOBAL)');
        
        if (avatarWindow && !avatarWindow.isDestroyed()) {
          avatarWindow.webContents.send('voice-record-start');
        }
      }
    });
    console.log(`   Alt+Space DOWN: ${altDownRegistered ? '✅ REGISTERED' : '❌ FAILED'}`);
  }
  
  // Register UP event for Ctrl+Shift+Space
  try {
    const upRegistered = globalShortcut.register('Ctrl+Shift+Space', () => {
      if (isRecording) {
        isRecording = false;
        console.log('🎤 Ctrl+Shift+Space - STOP recording (GLOBAL)');
        
        if (avatarWindow && !avatarWindow.isDestroyed()) {
          avatarWindow.webContents.send('voice-record-stop-auto');
        }
      }
    }, { keyup: true });
    
    console.log(`   Ctrl+Shift+Space UP: ${upRegistered ? '✅ REGISTERED' : '❌ FAILED'}`);
  } catch (err) {
    console.log(`   Ctrl+Shift+Space UP: ❌ ${err.message}`);
  }
      
  // ============ TOGGLE VISIBILITY ============
  const toggleVis = globalShortcut.register('Ctrl+Shift+A', () => {
    console.log('👁️ Toggle avatar visibility');
    if (avatarWindow && !avatarWindow.isDestroyed()) {
      if (avatarWindow.isVisible()) {
        avatarWindow.hide();
      } else {
        avatarWindow.show();
        avatarWindow.setIgnoreMouseEvents(false);
      }
    }
  });
  console.log(`   Ctrl+Shift+A: ${toggleVis ? '✅' : '❌'}`);
  
  console.log('========================================');
  console.log('🎤 PUSH-TO-TALK: Hold Ctrl+Shift+Space');
  console.log('   (Release to send)');
  console.log('========================================');
}

// ============ IPC HANDLERS ============
ipcMain.on('recording-started', () => {
  console.log('🔊 Renderer confirmed recording started');
});

ipcMain.on('recording-stopped', () => {
  console.log('🔇 Renderer confirmed recording stopped');
});

// ============ APP LIFECYCLE ============
app.whenReady().then(async () => {
  const { session } = require('electron');
  session.defaultSession.clearCache();
  
  console.log('🧹 Cache cleared');
  console.log('========================================');
  console.log('🎬 ELECTRON AVATAR - WITH CLICK FIXES');
  console.log('========================================');
  
  createWindow();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  console.log('👋 Global shortcuts unregistered');
  
  if (visibilityCheckInterval) {
    clearInterval(visibilityCheckInterval);
  }
  
  console.log('👋 Cleanup complete');
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (avatarWindow === null) {
    createWindow();
  }
});