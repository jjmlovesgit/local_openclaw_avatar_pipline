import sys
import os
import importlib

print("="*50)
print("SYSTEM CHECK")
print("="*50)

print(f"\n📁 Current directory: {os.getcwd()}")
print(f"🐍 Python: {sys.executable}")
print(f"📦 Environment: {os.environ.get('CONDA_DEFAULT_ENV', 'Not in conda')}")

# Check model file
model_path = "hey_jarvis_v0.1.onnx"
if os.path.exists(model_path):
    size = os.path.getsize(model_path)
    print(f"✅ Wake word model: {model_path} ({size:,} bytes)")
else:
    print(f"❌ Wake word model NOT FOUND: {model_path}")

# Check packages
packages = ['fastapi', 'uvicorn', 'webrtcvad', 'openwakeword', 'httpx', 'numpy']
for pkg in packages:
    try:
        mod = importlib.import_module(pkg)
        version = getattr(mod, '__version__', 'unknown')
        print(f"✅ {pkg}: {version}")
    except ImportError:
        print(f"❌ {pkg}: NOT INSTALLED")

print("\n" + "="*50)