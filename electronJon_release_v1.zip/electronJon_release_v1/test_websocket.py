# Create test_websocket.py

import asyncio
import websockets
import json

async def test():
    uri = 'ws://localhost:8002/ws/realtime/jonnydepp'
    print(f'Connecting to {uri}...')
    async with websockets.connect(uri) as ws:
        print('✅ Connected!')
        for i in range(3):
            msg = await ws.recv()
            data = json.loads(msg)
            print(f'📨 {data["type"]}: {data.get("message", "")}')
        print('\n✅ WebSocket working!')

asyncio.run(test())